Place your app assets here.

- Replace Assets.xcassets/Logo.imageset/Logo.png with the provided logo image (square PNG recommended, 1024x1024).
- The sample references an asset named "Logo".